import javax.mail.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;


public class MailReceiver {

    private final transient Properties props = System.getProperties();

    private transient MailAuthenticator authenticator;
    
    private transient Session session;
    
    public MailReceiver(final String pop3HostName, final String username,
            final String password) {
init(username, password, pop3HostName);
}

    private void init(String username, String password, String pop3HostName) {
    	int port = 995;
       
        props.put("mail.pop3.port", port); 
        props.put("mail.store.protocol", "pop3");
        props.put("mail.pop3.host", "pop.gmail.com");
        
        authenticator = new MailAuthenticator(username, password);
        
        session = Session.getInstance(props,authenticator);
    }

    public void receive() throws MessagingException, IOException {
        
        Store store = session.getStore();
        store.connect();

        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        Message[] messages = folder.getMessages(1,2);

        int mailCounts = messages.length;
        for(int i = 0; i < mailCounts; i++) {

            String subject = messages[i].getSubject();
            String from = (messages[i].getFrom()[0]).toString();

            System.out.println(" " + (i+1) + "" + subject);
            System.out.println(" " + (i+1) + "" + from);

            System.out.println("");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if("yes".equalsIgnoreCase(input)) {
                
                messages[i].writeTo(System.out);
            }
        }
        folder.close(false);
        store.close();
    }
}


