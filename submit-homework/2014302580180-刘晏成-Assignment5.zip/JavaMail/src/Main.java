import javax.mail.MessagingException;
import java.io.IOException;


public class Main {
    public static void main(String[] args) {

        MailReceiver smr = new MailReceiver("pop.gmail.com","liuyancheng2882152@gmail.com","Liuyancheng152");
        try {
            smr.receive();
        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
